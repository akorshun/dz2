$('button').on('click', function(){
	$('#toggle').toggleClass('mod-block')
});